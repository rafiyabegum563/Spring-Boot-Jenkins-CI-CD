package ma.projet.gestionprofesseurs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionProfesseursApplicationTests {

    @Test
    void contextLoads() {
    }

}
