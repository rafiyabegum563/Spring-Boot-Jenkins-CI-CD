package ma.projet.gestionprofesseurs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionProfesseursApplication {

    public static void main(String[] args) {
        SpringApplication.run(GestionProfesseursApplication.class, args);
    }

}
